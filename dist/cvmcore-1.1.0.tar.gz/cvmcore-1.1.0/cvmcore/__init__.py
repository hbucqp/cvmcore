# -*- coding:utf-8 -*-

__title__ = 'cvmbcore'
__description__ = 'core function of data analysis used by SZQ lab from China Agricultural University'
__url__ = 'https://github.com/hbucqp/cvmcore'
__version__ = "1.1.0"
__author__ = 'Qingpo Cui'
__author_email__ = 'cqp@cau.edu.cn'
__license__ = 'MIT'
__copyright__ = 'Copyright 2023 Qingpo Cui'
