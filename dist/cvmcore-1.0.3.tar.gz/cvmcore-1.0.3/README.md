cvmcore
===
![PYPI](https://img.shields.io/pypi/v/cvmbcore)

## Introduction
The core function of data analysis used by SZQ lab from China Agricultural University
