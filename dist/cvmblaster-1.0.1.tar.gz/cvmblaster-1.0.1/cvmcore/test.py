from cvmbox import cvmbox


cvmbox.single_cgmlst2ref('inputdir', 'test')
